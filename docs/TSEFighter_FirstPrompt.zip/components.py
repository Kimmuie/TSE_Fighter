"""components.py — ชิ้นส่วนย่อยที่ Fighter ประกอบเข้าด้วยกัน (Composition, หลักการ OOP ข้อ 3)

Fighter "มี" StateMachine, Hitbox และ InputController แทนที่จะ "เป็น" สิ่งเหล่านั้น
แต่ละคลาสรับผิดชอบงานเดียว (Single Responsibility)
"""
from __future__ import annotations

from enum import Enum, auto
from typing import TYPE_CHECKING, Any, Optional

import pygame

from events import HitInfo

if TYPE_CHECKING:
    from entities import Fighter


class State(Enum):
    """สถานะที่เป็นไปได้ของนักสู้"""

    IDLE = auto()
    WALK = auto()
    JUMP = auto()
    ATTACK = auto()
    CAST = auto()
    HIT = auto()
    KO = auto()


class StateMachine:
    """ตัวจัดการสถานะของนักสู้ (State Machine)

    ควบคุมว่านักสู้ "ลงมือทำอะไรได้หรือไม่" ผ่านตัวล็อกเวลา (lock)
    เช่น ระหว่างต่อยหรือโดนตี จะสั่งการใหม่ไม่ได้จนกว่า lock จะหมด
    """

    _AUTO_RECOVER = (State.ATTACK, State.CAST, State.HIT)

    def __init__(self) -> None:
        self._state = State.IDLE
        self._lock = 0.0
        self.elapsed = 0.0

    @property
    def state(self) -> State:
        return self._state

    @property
    def can_act(self) -> bool:
        """True เมื่อไม่ถูกล็อกและยังไม่ KO"""
        return self._state != State.KO and self._lock <= 0.0

    def change(self, new_state: State, lock: float = 0.0) -> None:
        """เปลี่ยนสถานะพร้อมล็อกการกระทำเป็นเวลา lock วินาที"""
        self._state = new_state
        self._lock = max(0.0, lock)
        self.elapsed = 0.0

    def locomote(self, new_state: State) -> None:
        """เปลี่ยนสถานะการเคลื่อนที่ (IDLE/WALK/JUMP) โดยไม่รีเซ็ตเวลา"""
        if self._lock <= 0.0 and self._state in (State.IDLE, State.WALK, State.JUMP):
            self._state = new_state

    def update(self, dt: float) -> None:
        self.elapsed += dt
        if self._lock > 0.0:
            self._lock -= dt
            if self._lock <= 0.0 and self._state in self._AUTO_RECOVER:
                self._state = State.IDLE
                self.elapsed = 0.0


class Hitbox:
    """กล่องโจมตี (Hitbox) ของนักสู้

    "ติดอาวุธ" (arm) ด้วยพารามิเตอร์การโจมตี แล้วจะ active หลังช่วง windup
    และหมดอายุเองเมื่อพ้นช่วง active ตำแหน่งคำนวณจากตัวเจ้าของ + ทิศที่หัน
    """

    def __init__(self) -> None:
        self._p: Optional[dict[str, Any]] = None
        self._timer = 0.0
        self._has_hit = False

    def arm(
        self,
        damage: float,
        width: int,
        height: int,
        offset_x: int,
        offset_y: int,
        windup: float,
        active: float,
        knockback: tuple[float, float] = (0.0, 0.0),
        unblockable: bool = False,
        stun: float = 0.3,
        tags: tuple[str, ...] | set[str] | frozenset[str] = (),
    ) -> None:
        """เตรียมการโจมตีใหม่ (รีเซ็ตสถานะ has_hit ด้วย)"""
        self._p = dict(
            damage=damage, width=width, height=height, offset_x=offset_x,
            offset_y=offset_y, windup=windup, active=active, knockback=knockback,
            unblockable=unblockable, stun=stun, tags=frozenset(tags),
        )
        self._timer = 0.0
        self._has_hit = False

    def clear(self) -> None:
        self._p = None

    def update(self, dt: float) -> None:
        if self._p is None:
            return
        self._timer += dt
        if self._timer > self._p["windup"] + self._p["active"]:
            self._p = None

    @property
    def is_active(self) -> bool:
        """True เมื่ออยู่ในช่วงที่โจมตีติดได้ และยังไม่เคยโดนใคร"""
        if self._p is None or self._has_hit:
            return False
        return self._p["windup"] <= self._timer <= self._p["windup"] + self._p["active"]

    def mark_hit(self) -> None:
        self._has_hit = True

    def rect_for(self, owner: "Fighter") -> pygame.Rect:
        """คำนวณสี่เหลี่ยมของ hitbox จากตำแหน่งและทิศของเจ้าของ"""
        assert self._p is not None
        r = pygame.Rect(0, 0, self._p["width"], self._p["height"])
        r.center = (
            owner.rect.centerx + owner.facing * self._p["offset_x"],
            owner.rect.bottom - self._p["offset_y"],
        )
        return r

    def build_hit(self, owner: "Fighter") -> HitInfo:
        """สร้าง HitInfo (คูณตัวคูณดาเมจของเจ้าของ ซึ่งคลาสลูก override ได้)"""
        assert self._p is not None
        p = self._p
        return HitInfo(
            attacker=owner,
            damage=p["damage"] * owner.outgoing_damage_multiplier(),
            knockback=pygame.Vector2(p["knockback"]),
            direction=owner.facing,
            unblockable=p["unblockable"],
            stun=p["stun"],
            tags=p["tags"],
        )


class InputController:
    """ตัวแปลงปุ่มคีย์บอร์ดเป็น "action" ของเกม (เช่น skill1, attack, left)

    แยกการรับ input ออกจากตัวนักสู้ ทำให้สลับผังปุ่มของผู้เล่นได้โดยไม่แก้ Fighter
    """

    def __init__(self, keymap: dict[str, tuple[int, ...]], labels: dict[str, str]) -> None:
        self._keymap = keymap
        self._labels = labels

    @classmethod
    def player_one(cls) -> "InputController":
        """ผังปุ่มผู้เล่น 1: A/D เดิน, W กระโดด, S ป้องกัน, F โจมตี, Q/E/C สกิล"""
        km = {
            "left": (pygame.K_a,), "right": (pygame.K_d,), "jump": (pygame.K_w,),
            "block": (pygame.K_s,), "attack": (pygame.K_f,),
            "skill1": (pygame.K_q,), "skill2": (pygame.K_e,), "skill3": (pygame.K_c,),
        }
        lb = {"attack": "F", "skill1": "Q", "skill2": "E", "skill3": "C"}
        return cls(km, lb)

    @classmethod
    def player_two(cls) -> "InputController":
        """ผังปุ่มผู้เล่น 2: ลูกศรเดิน/กระโดด/ป้องกัน, RShift โจมตี, Numpad 1-3 (หรือแถวบน 1-3) สกิล"""
        km = {
            "left": (pygame.K_LEFT,), "right": (pygame.K_RIGHT,), "jump": (pygame.K_UP,),
            "block": (pygame.K_DOWN,), "attack": (pygame.K_RSHIFT, pygame.K_KP0),
            "skill1": (pygame.K_KP1, pygame.K_1), "skill2": (pygame.K_KP2, pygame.K_2),
            "skill3": (pygame.K_KP3, pygame.K_3),
        }
        lb = {"attack": "R-SHIFT", "skill1": "NUM 1", "skill2": "NUM 2", "skill3": "NUM 3"}
        return cls(km, lb)

    def label(self, action: str) -> str:
        """ข้อความปุ่มสำหรับแสดงใน UI"""
        return self._labels.get(action, "?")

    def action_for_event(self, event: pygame.event.Event) -> Optional[str]:
        """คืนชื่อ action ที่ตรงกับ KEYDOWN (หรือ None)"""
        if event.type != pygame.KEYDOWN:
            return None
        for action, keys in self._keymap.items():
            if event.key in keys:
                return action
        return None

    def is_held(self, action: str, pressed: Any) -> bool:
        """เช็กว่า action นี้ถูกกดค้างอยู่หรือไม่"""
        return any(pressed[k] for k in self._keymap.get(action, ()))
