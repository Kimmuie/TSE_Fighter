"""stage.py — ฉากหลังสนามต่อสู้ (ชายหาดยามพระอาทิตย์ตก)"""
from __future__ import annotations

import math

import pygame

import settings as S
from assets import get_font


class Stage:
    """สนามต่อสู้แนวนอนแบบคงที่: ท้องฟ้าไล่สี ดวงอาทิตย์ ต้นปาล์ม ทะเล และพื้นทราย

    วาดพื้นหลังครั้งเดียวลง Surface แล้วนำมาแปะซ้ำทุกเฟรม (ประหยัด CPU)
    มีหน้าที่เดียวคือ "ภาพของสนาม" ไม่ยุ่งกับตรรกะการต่อสู้
    """

    NAME = "BEACH ARENA (SUNSET SHORE)"

    def __init__(self) -> None:
        self.rect = S.ARENA.copy()
        self.ground_y = S.GROUND_Y
        self._bg = self._build_background()

    # ------------------------------------------------------------------ build
    def _build_background(self) -> pygame.Surface:
        w, h = self.rect.size
        surf = pygame.Surface((w, h))
        horizon = h - 110
        stops = [(0.0, (251, 115, 15)), (0.55, (251, 191, 36)), (1.0, (118, 190, 190))]
        for y in range(horizon):
            t = y / horizon
            for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
                if t0 <= t <= t1:
                    k = (t - t0) / (t1 - t0)
                    color = tuple(int(c0[i] + (c1[i] - c0[i]) * k) for i in range(3))
                    break
            pygame.draw.line(surf, color, (0, y), (w, y))
        # ดวงอาทิตย์
        pygame.draw.circle(surf, (254, 232, 196), (w // 2, 82), 62)
        pygame.draw.circle(surf, S.GOLD, (w // 2, 82), 62, 5)
        # ทะเล + พื้นทราย
        pygame.draw.rect(surf, (11, 140, 205), (0, horizon, w, 62))
        pygame.draw.line(surf, (200, 240, 255), (0, horizon), (w, horizon), 2)
        pygame.draw.rect(surf, (232, 177, 8), (0, h - 48, w, 48))
        pygame.draw.rect(surf, (250, 226, 120), (0, h - 48, w, 10))
        # ต้นปาล์มเงาดำ
        self._palm(surf, 84, h - 48, lean=1)
        self._palm(surf, w - 84, h - 48, lean=-1)
        # ป้ายข้อความ
        font = get_font(11, bold=True)
        surf.blit(font.render("[ ARENA FLOOR: SUNSET SANDS ]", True, (110, 70, 0)), (24, h - 28))
        txt = font.render("SHORELINE SURF", True, (110, 70, 0))
        surf.blit(txt, (w - txt.get_width() - 24, h - 28))
        return surf

    @staticmethod
    def _palm(surf: pygame.Surface, x: int, base_y: int, lean: int) -> None:
        col = (38, 40, 45)
        pts = [(x, base_y), (x + lean * 4, base_y - 60), (x - lean * 4, base_y - 110), (x - lean * 12, base_y - 140)]
        pygame.draw.lines(surf, col, False, pts, 8)
        top = pts[-1]
        for ang in (-160, -125, -90, -55, -20, 15):
            a = math.radians(ang)
            mid = (top[0] + math.cos(a) * 28, top[1] + math.sin(a) * 18)
            end = (top[0] + math.cos(a) * 58, top[1] + math.sin(a) * 22 + 14)
            pygame.draw.lines(surf, col, False, [top, mid, end], 6)

    # ------------------------------------------------------------------- draw
    def draw(self, surface: pygame.Surface, t: float = 0.0) -> None:
        """วาดฉากหลัง พร้อมเส้นคลื่นเคลื่อนไหวเล็กน้อย"""
        surface.blit(self._bg, self.rect.topleft)
        horizon = self.rect.bottom - 110
        for i in range(0, self.rect.w, 60):
            y = horizon + 24 + int(math.sin(t * 2 + i * 0.05) * 3)
            pygame.draw.line(surface, (120, 200, 235), (self.rect.x + i, y), (self.rect.x + i + 30, y), 2)
        pygame.draw.rect(surface, S.WHITE, self.rect, 1)
