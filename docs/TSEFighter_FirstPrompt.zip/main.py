"""main.py — จุดเริ่มต้นของเกม STREET CLASH

State machine ของเกม:   Menu -> Character Select -> Battle -> Game Over
รัน:  python main.py        (ต้องติดตั้ง pygame ก่อน:  pip install pygame)
"""
from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import pygame

import settings as S
from combat import BattleWorld
from components import InputController
from entities import FloatingText, Fighter, Kai, Nyx
from events import EventDispatcher
from stage import Stage
from ui import ComboBanner, FighterCard, HUD, RosterGrid, draw_text


# =============================================================================
class Scene(ABC):
    """คลาสแม่ของทุกฉาก (Abstract Base Class) — ทุกฉากต้อง implement 3 เมธอด

    Game เรียกฉากปัจจุบันแบบ Polymorphism โดยไม่ต้องรู้ว่าเป็นฉากอะไร
    """

    def __init__(self, game: "Game") -> None:
        self.game = game

    @abstractmethod
    def handle_event(self, event: pygame.event.Event) -> None: ...

    @abstractmethod
    def update(self, dt: float) -> None: ...

    @abstractmethod
    def draw(self, surface: pygame.Surface) -> None: ...


# =============================================================================
class MenuScene(Scene):
    """ฉากเมนูหลัก: ชื่อเกม ข้อความกระพริบ และตารางปุ่มควบคุม"""

    def __init__(self, game: "Game") -> None:
        super().__init__(game)
        self._t = 0.0

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.game.change_scene(SelectScene(self.game))
            elif event.key == pygame.K_ESCAPE:
                self.game.running = False

    def update(self, dt: float) -> None:
        self._t += dt

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill(S.BG)
        draw_text(surface, "STREET", 120, S.P1_COLOR, (640 - 8, 120), "midtop", display=True)
        draw_text(surface, "CLASH", 120, S.P2_COLOR, (640 + 8, 235), "midtop", display=True)
        draw_text(surface, "2-PLAYER LOCAL FIGHTER", 16, S.GREY, (640, 380), "midtop")
        if int(self._t * 2) % 2 == 0:
            draw_text(surface, "PRESS ENTER", 26, S.WHITE, (640, 430), "midtop")
        for col, x, lines in (
            (S.P1_COLOR, 260, ["PLAYER 1", "A / D  move     W  jump     S  guard", "F  attack", "Q  E  C  skills"]),
            (S.P2_COLOR, 1020, ["PLAYER 2", "← / →  move   ↑  jump   ↓  guard", "R-SHIFT  attack", "NUM 1 2 3  skills (or 1 2 3)"]),
        ):
            pygame.draw.rect(surface, col, (x - 230, 520, 460, 130), 1)
            for i, line in enumerate(lines):
                draw_text(surface, line, 14 if i else 16, col if i == 0 else S.WHITE, (x, 538 + i * 26), "midtop")


# =============================================================================
@dataclass(frozen=True)
class RosterEntry:
    """ข้อมูลหนึ่งช่องในรายชื่อนักสู้ (cls=None หมายถึงยังล็อกอยู่)"""

    name: str
    title: str
    cls: Optional[type[Fighter]] = None


ROSTER = [
    RosterEntry("KAI", "THE URBAN BRAWLER", Kai),
    RosterEntry("NYX", "SHADOW SHINOBI", Nyx),
    RosterEntry("VIKTOR", "COMING SOON"), RosterEntry("ROXY", "COMING SOON"),
    RosterEntry("RAIDEN-X", "COMING SOON"), RosterEntry("VESPER", "COMING SOON"),
    RosterEntry("OMEGA", "COMING SOON"), RosterEntry("GHOST", "COMING SOON"),
]


class SelectScene(Scene):
    """ฉากเลือกนักสู้: ผู้เล่นแต่ละคนขยับเคอร์เซอร์ด้วยปุ่มเดิน และยืนยันด้วยปุ่มโจมตี"""

    def __init__(self, game: "Game") -> None:
        super().__init__(game)
        self._cursor = [0, 1]
        self._ready = [False, False]
        self._countdown: Optional[float] = None
        self._previews: dict[tuple[int, str], Fighter] = {}
        self.grid = RosterGrid(pygame.Rect(420, 98, 440, 590), [e.name for e in ROSTER], [e.cls is not None for e in ROSTER])
        self.cards = (FighterCard(pygame.Rect(24, 98, 380, 590), S.P1_COLOR, "1", False),
                      FighterCard(pygame.Rect(876, 98, 380, 590), S.P2_COLOR, "2", True))

    def _preview(self, player: int) -> Optional[Fighter]:
        entry = ROSTER[self._cursor[player]]
        if entry.cls is None:
            return None
        key = (player, entry.name)
        if key not in self._previews:
            color = S.P1_COLOR if player == 0 else S.P2_COLOR
            self._previews[key] = entry.cls(color, self.game.controllers[player], EventDispatcher(), tag=f"{player + 1}P")
        return self._previews[key]

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_ESCAPE:
            self.game.change_scene(MenuScene(self.game))
            return
        for p, ctrl in enumerate(self.game.controllers):
            action = ctrl.action_for_event(event)
            if action == "attack":
                if ROSTER[self._cursor[p]].cls is not None:
                    self._ready[p] = not self._ready[p]
            elif not self._ready[p]:
                step = {"left": -1, "right": 1, "jump": -2, "block": 2}.get(action or "")
                if step:
                    self._cursor[p] = (self._cursor[p] + step) % len(ROSTER)
        if all(self._ready) and self._countdown is None:
            self._countdown = 0.7

    def update(self, dt: float) -> None:
        if not all(self._ready):
            self._countdown = None
        elif self._countdown is not None:
            self._countdown -= dt
            if self._countdown <= 0:
                c1, c2 = ROSTER[self._cursor[0]].cls, ROSTER[self._cursor[1]].cls
                assert c1 is not None and c2 is not None
                self.game.change_scene(BattleScene(self.game, c1, c2))

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill(S.BG)
        draw_text(surface, "SELECT YOUR FIGHTER", 58, S.WHITE, (640, 16), "midtop", display=True)
        for p, card in enumerate(self.cards):
            entry = ROSTER[self._cursor[p]]
            card.draw(surface, entry.name, entry.title, self._preview(p), self._ready[p])
        self.grid.draw(surface, (self._cursor[0], self._cursor[1]), (self._ready[0], self._ready[1]))
        hint = "P1: A/D/W/S move • F confirm      P2: arrows move • R-SHIFT confirm      ESC back"
        draw_text(surface, hint, 11, S.GREY, (640, 716), "midbottom")
        if self._countdown is not None:
            draw_text(surface, "FIGHT!", 30, S.GOLD, (640, 80), "midtop", display=True)


# =============================================================================
class BattleScene(Scene):
    """ฉากต่อสู้: สร้างโลก (BattleWorld) นักสู้ HUD แล้วจัดการกติกาแบบ 3 ยก ชนะ 2 ยก

    เป็น Observer: subscribe เหตุการณ์ on_hit / on_skill_cast / on_ko ผ่าน EventDispatcher
    เฟสของยก: intro -> fight -> round_end
    """

    INTRO_TIME = 1.5
    END_TIME = 2.4

    def __init__(self, game: "Game", cls1: type[Fighter], cls2: type[Fighter]) -> None:
        super().__init__(game)
        self.cls1, self.cls2 = cls1, cls2
        self.dispatcher = EventDispatcher()
        self.world = BattleWorld(self.dispatcher)
        self.stage = Stage()
        self.hud = HUD()
        self.combo = ComboBanner()
        c1, c2 = game.controllers
        self.fighters: list[Fighter] = [
            cls1(S.P1_COLOR, c1, self.dispatcher, tag="1P", x=S.ARENA.left + 260, facing=1),
            cls2(S.P2_COLOR, c2, self.dispatcher, tag="2P", x=S.ARENA.right - 260, facing=-1),
        ]
        for f in self.fighters:
            self.world.add_fighter(f)
        self.dispatcher.subscribe("on_hit", self._on_hit)
        self.dispatcher.subscribe("on_hit", self.combo.on_hit)
        self.dispatcher.subscribe("on_skill_cast", self._on_skill_cast)
        self.dispatcher.subscribe("on_ko", self._on_ko)
        self.wins = [0, 0]
        self.round_no = 0
        self._t = 0.0
        self._banner = ""
        self._start_round()

    # ------------------------------------------------------------------ rounds
    def _start_round(self) -> None:
        self.round_no += 1
        self.time_left = float(S.ROUND_TIME)
        self.phase = "intro"
        self.phase_time = 0.0
        self._banner = ""
        self.world.projectiles.empty()
        self.world.effects.empty()
        for f, x, face in zip(self.fighters, (S.ARENA.left + 260, S.ARENA.right - 260), (1, -1)):
            f.reset(x, face)
            f.input_enabled = False

    def _end_round(self, banner: str, winner: Optional[int]) -> None:
        if self.phase != "fight":
            return
        if winner is not None:
            self.wins[winner] += 1
        self.phase, self.phase_time, self._banner = "round_end", 0.0, banner
        for f in self.fighters:
            f.input_enabled = False

    # --------------------------------------------------------------- observers
    def _on_hit(self, attacker: Fighter, target: Fighter, damage: float, blocked: bool, **_: object) -> None:
        target.burst(8 if not blocked else 3, attacker.color, 240)

    def _on_skill_cast(self, caster: Fighter, skill: object, **_: object) -> None:
        self.world.spawn_effect(FloatingText(skill.NAME, caster.pos.x, caster.pos.y - 200, caster.color))  # type: ignore[attr-defined]

    def _on_ko(self, loser: Fighter, winner: Fighter, **_: object) -> None:
        idx = self.fighters.index(winner) if winner in self.fighters else 1 - self.fighters.index(loser)
        self._end_round("K.O.!", idx)

    # ------------------------------------------------------------------- loop
    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.change_scene(MenuScene(self.game))
            return
        if self.phase == "fight":
            for f in self.fighters:
                f.handle_event(event)

    def update(self, dt: float) -> None:
        self._t += dt
        self.phase_time += dt
        if self.phase == "intro" and self.phase_time >= self.INTRO_TIME:
            self.phase, self.phase_time = "fight", 0.0
            for f in self.fighters:
                f.input_enabled = True
        elif self.phase == "fight":
            self.time_left -= dt
            if self.time_left <= 0:
                a, b = self.fighters[0].hp, self.fighters[1].hp
                self._end_round("TIME!" if a != b else "DRAW", None if a == b else (0 if a > b else 1))
        elif self.phase == "round_end" and self.phase_time >= self.END_TIME:
            if max(self.wins) >= S.ROUNDS_TO_WIN:
                self.game.change_scene(GameOverScene(self.game, self.cls1, self.cls2, self.wins.index(max(self.wins))))
                return
            self._start_round()
        self.world.update(dt)
        self.hud.update(dt, *self.fighters)
        self.combo.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill(S.BG)
        surface.set_clip(S.ARENA)
        self.stage.draw(surface, self._t)
        self.world.draw(surface)
        surface.set_clip(None)
        self.combo.draw(surface)
        self.hud.draw(surface, self.fighters[0], self.fighters[1], self.time_left, self.round_no,
                      self.wins, self.stage.NAME)
        text = ""
        if self.phase == "intro":
            text = f"ROUND {self.round_no}" if self.phase_time < 0.9 else "FIGHT!"
        elif self.phase == "round_end":
            text = self._banner
        if text:
            draw_text(surface, text, 90, S.WHITE, (S.ARENA.centerx + 4, S.ARENA.y + 150), "center", display=True)
            draw_text(surface, text, 90, S.GOLD, (S.ARENA.centerx, S.ARENA.y + 146), "center", display=True)


# =============================================================================
class GameOverScene(Scene):
    """ฉากจบเกม: ประกาศผู้ชนะ ENTER = รีแมตช์, C = เลือกตัวใหม่, ESC = เมนู"""

    def __init__(self, game: "Game", cls1: type[Fighter], cls2: type[Fighter], winner: int) -> None:
        super().__init__(game)
        self.cls1, self.cls2, self.winner = cls1, cls2, winner

    def handle_event(self, event: pygame.event.Event) -> None:
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_RETURN:
            self.game.change_scene(BattleScene(self.game, self.cls1, self.cls2))
        elif event.key == pygame.K_c:
            self.game.change_scene(SelectScene(self.game))
        elif event.key == pygame.K_ESCAPE:
            self.game.change_scene(MenuScene(self.game))

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface) -> None:
        surface.fill(S.BG)
        cls = (self.cls1, self.cls2)[self.winner]
        col = (S.P1_COLOR, S.P2_COLOR)[self.winner]
        draw_text(surface, "GAME OVER", 40, S.GREY, (640, 150), "midtop", display=True)
        draw_text(surface, f"{cls.NAME} WINS", 120, col, (640, 220), "midtop", display=True)
        draw_text(surface, f"PLAYER {self.winner + 1} • {cls.TITLE}", 18, S.WHITE, (640, 380), "midtop")
        draw_text(surface, "ENTER  rematch      C  character select      ESC  menu", 16, S.GREY, (640, 480), "midtop")


# =============================================================================
class Game:
    """คลาสหลักของโปรแกรม: สร้างหน้าต่าง ลูปเกม และสลับฉาก (Menu -> Select -> Battle -> Game Over)"""

    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption(S.TITLE)
        self.screen = pygame.display.set_mode((S.WIDTH, S.HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True
        self.controllers = (InputController.player_one(), InputController.player_two())
        self.scene: Scene = MenuScene(self)

    def change_scene(self, scene: Scene) -> None:
        self.scene = scene

    def run(self) -> None:
        while self.running:
            dt = min(self.clock.tick(S.FPS) / 1000.0, 1 / 30)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                else:
                    self.scene.handle_event(event)
            self.scene.update(dt)
            self.scene.draw(self.screen)
            pygame.display.flip()
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    Game().run()
