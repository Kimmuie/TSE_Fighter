"""ui.py — องค์ประกอบ UI ทั้งหมด: HUD, แถบเลือด, แถบสกิล, การ์ดเลือกตัวละคร, แบนเนอร์คอมโบ"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING, Optional

import pygame

import settings as S
from assets import ImageLoader, get_font

if TYPE_CHECKING:
    from entities import Fighter


# ----------------------------------------------------------------- helpers
def draw_text(surface: pygame.Surface, text: str, size: int, color: tuple[int, int, int],
              pos: tuple[int, int], anchor: str = "topleft", display: bool = False) -> pygame.Rect:
    """วาดข้อความ (anchor เช่น topleft / center / midright)"""
    img = get_font(size, display=display).render(text, True, color)
    rect = img.get_rect(**{anchor: pos})
    surface.blit(img, rect)
    return rect


def wrap_text(text: str, size: int, max_w: int) -> list[str]:
    font = get_font(size, bold=False)
    lines, cur = [], ""
    for word in text.split():
        test = f"{cur} {word}".strip()
        if font.size(test)[0] <= max_w:
            cur = test
        else:
            lines.append(cur)
            cur = word
    return lines + [cur] if cur else lines


def draw_icon(surface: pygame.Surface, kind: str, c: tuple[int, int, int], color: tuple[int, int, int]) -> None:
    """ไอคอนสกิลแบบเรขาคณิตง่ายๆ (แทนรูปจริง)"""
    x, y = c
    if kind == "hook":
        pygame.draw.lines(surface, color, False, [(x - 5, y + 6), (x - 5, y - 2), (x + 3, y - 6), (x + 6, y - 1)], 2)
    elif kind == "charge":
        for dx in (-5, 2):
            pygame.draw.lines(surface, color, False, [(x + dx, y - 6), (x + dx + 5, y), (x + dx, y + 6)], 2)
    elif kind == "rush":
        for dx in (-5, 0, 5):
            pygame.draw.line(surface, color, (x + dx, y - 6), (x + dx, y + 6), 2)
    elif kind == "dash":
        for dx in (-6, 1):
            pygame.draw.polygon(surface, color, [(x + dx, y - 5), (x + dx + 6, y), (x + dx, y + 5)], 1)
    elif kind == "kunai":
        pygame.draw.polygon(surface, color, [(x, y - 7), (x + 6, y + 6), (x - 6, y + 6)], 1)
    else:
        for dy in (-5, 0, 5):
            pygame.draw.line(surface, color, (x - 6, y + dy), (x + 6, y + dy), 1)


# ------------------------------------------------------------------ widgets
class HealthBar:
    """แถบเลือด — ค่า ratio (0..1) ถูกตรวจช่วงด้วย setter และค่อยๆ เลื่อนแบบนุ่มนวล

    align_right=True ใช้กับผู้เล่น 2 (แถบหดเข้าหาขวา)
    """

    def __init__(self, rect: tuple[int, int, int, int], color: tuple[int, int, int], align_right: bool = False) -> None:
        self.rect = pygame.Rect(rect)
        self.color = color
        self.align_right = align_right
        self._target = 1.0
        self._shown = 1.0

    @property
    def ratio(self) -> float:
        return self._target

    @ratio.setter
    def ratio(self, value: float) -> None:
        self._target = max(0.0, min(1.0, float(value)))

    def update(self, dt: float) -> None:
        self._shown += (self._target - self._shown) * min(1.0, dt * 9)

    def draw(self, surface: pygame.Surface) -> None:
        pygame.draw.rect(surface, S.DARK, self.rect)
        inner = self.rect.inflate(-6, -6)
        w = int(inner.w * self._shown)
        fill = pygame.Rect(inner.right - w if self.align_right else inner.x, inner.y, w, inner.h)
        pygame.draw.rect(surface, self.color, fill)
        pygame.draw.rect(surface, self.color, self.rect, 1)


class SkillBar:
    """แถบแสดงสกิล 3 ช่อง (ป้ายปุ่ม, ไอคอน, ชื่อ, คูลดาวน์) ของนักสู้หนึ่งคน"""

    def __init__(self, rect: pygame.Rect, color: tuple[int, int, int]) -> None:
        self.rect = rect
        self.color = color

    def draw(self, surface: pygame.Surface, fighter: "Fighter") -> None:
        gap = 8
        slot_w = (self.rect.w - 2 * gap) // 3
        for i, skill in enumerate(fighter.skills):
            r = pygame.Rect(self.rect.x + i * (slot_w + gap), self.rect.y, slot_w, self.rect.h)
            ready = skill.can_cast(fighter)
            pygame.draw.rect(surface, S.PANEL, r)
            pygame.draw.rect(surface, self.color if ready else S.GREY, r, 1)
            badge = pygame.Rect(r.x + 8, r.centery - 9, 56, 18)
            pygame.draw.rect(surface, self.color, badge)
            draw_text(surface, f"[ {skill.key_label} ]", 10, S.DARK, badge.center, "center")
            icon_c = (r.x + 86, r.centery)
            pygame.draw.circle(surface, self.color, icon_c, 13, 1)
            draw_icon(surface, skill.ICON, icon_c, self.color)
            draw_text(surface, skill.NAME, 10, S.WHITE if ready else S.GREY, (r.x + 106, r.centery - 6))
            draw_text(surface, f"EN {int(skill.ENERGY_COST)}", 9, S.GREY, (r.right - 6, r.bottom - 4), "bottomright")
            if skill.cooldown_ratio > 0:
                ov = pygame.Surface((r.w, int(r.h * skill.cooldown_ratio)), pygame.SRCALPHA)
                ov.fill((0, 0, 0, 160))
                surface.blit(ov, r.topleft)
                draw_text(surface, f"{skill.cooldown_left:.1f}s", 13, S.WHITE, (r.right - 8, r.centery - 4), "midright")


class HUD:
    """HUD ด้านบน (ชื่อ, % HP, แถบเลือด, ตัวจับเวลา, จุดนับยก) + แถบสกิลด้านล่าง"""

    PANEL = pygame.Rect(16, 10, 1248, 100)

    def __init__(self) -> None:
        self.bar1 = HealthBar((32, 76, 500, 16), S.P1_COLOR)
        self.bar2 = HealthBar((748, 76, 500, 16), S.P2_COLOR, align_right=True)
        self.skills1 = SkillBar(pygame.Rect(16, 624, 616, 60), S.P1_COLOR)
        self.skills2 = SkillBar(pygame.Rect(648, 624, 616, 60), S.P2_COLOR)

    def update(self, dt: float, f1: "Fighter", f2: "Fighter") -> None:
        self.bar1.ratio, self.bar2.ratio = f1.hp / 100.0, f2.hp / 100.0
        self.bar1.update(dt)
        self.bar2.update(dt)

    def draw(self, surface: pygame.Surface, f1: "Fighter", f2: "Fighter", time_left: float,
             round_no: int, wins: list[int], arena_name: str) -> None:
        pygame.draw.rect(surface, S.PANEL, self.PANEL)
        pygame.draw.rect(surface, S.PANEL_LIGHT, self.PANEL, 1)
        pygame.draw.circle(surface, S.P1_COLOR, (36, 30), 5)
        draw_text(surface, "PLAYER 1", 12, S.P1_COLOR, (48, 23))
        draw_text(surface, "PLAYER 2", 12, S.P2_COLOR, (1228, 23), "topright")
        pygame.draw.circle(surface, S.P2_COLOR, (1244, 30), 5)

        badge = pygame.Rect(0, 0, 330, 26)
        badge.center = (640, 31)
        pygame.draw.rect(surface, S.DARK, badge)
        pygame.draw.rect(surface, S.GREY, badge, 1)
        draw_text(surface, f"ROUND {round_no} • {arena_name}", 11, S.WHITE, badge.center, "center")
        for i, x in enumerate((452, 470)):
            pygame.draw.circle(surface, S.P1_COLOR if wins[0] > i else S.PANEL_LIGHT, (x, 31), 6)
        for i, x in enumerate((810, 828)):
            pygame.draw.circle(surface, S.P2_COLOR if wins[1] > i else S.PANEL_LIGHT, (x, 31), 6)

        draw_text(surface, f"{f1.NAME} ({f1.TITLE})", 12, S.P1_COLOR, (32, 56))
        draw_text(surface, f"{int(round(f1.hp))}% HP", 20, S.P1_COLOR, (532, 50), "topright")
        draw_text(surface, f"{f2.NAME} ({f2.TITLE})", 12, S.P2_COLOR, (1248, 56), "topright")
        draw_text(surface, f"{int(round(f2.hp))}% HP", 20, S.P2_COLOR, (748, 50), "topleft")
        self.bar1.draw(surface)
        self.bar2.draw(surface)
        for rect, f, right in ((pygame.Rect(32, 96, 500, 4), f1, False), (pygame.Rect(748, 96, 500, 4), f2, True)):
            pygame.draw.rect(surface, S.DARK, rect)
            w = int(rect.w * f.energy / 100)
            pygame.draw.rect(surface, S.WHITE, (rect.right - w if right else rect.x, rect.y, w, rect.h))

        timer = pygame.Rect(600, 46, 80, 56)
        pygame.draw.rect(surface, S.DARK, timer)
        pygame.draw.rect(surface, S.WHITE, timer, 2)
        draw_text(surface, f"{max(0, math.ceil(time_left)):02d}", 34, S.WHITE, (640, 70), "center")
        draw_text(surface, "SECONDS", 9, S.GREY, (640, 94), "center")

        self.skills1.draw(surface, f1)
        self.skills2.draw(surface, f2)


class ComboBanner:
    """แบนเนอร์ "CLASH!/COMBO!" กลางสนาม — เป็น Observer ของเหตุการณ์ on_hit

    นับจำนวนฮิตและดาเมจรวม; ถ้าทั้งสองฝ่ายโดนภายใน 0.5 วินาทีจะขึ้น CLASH!
    """

    def __init__(self) -> None:
        self._hits = 0
        self._dmg = 0.0
        self._ttl = 0.0
        self._last: dict[str, float] = {}
        self._clock = 0.0
        self._clash = False

    def on_hit(self, attacker: "Fighter", target: "Fighter", damage: float, **_: object) -> None:
        if self._ttl <= 0:
            self._hits, self._dmg = 0, 0.0
        self._hits += 1
        self._dmg += damage
        self._last[attacker.tag] = self._clock
        others = [t for tag, t in self._last.items() if tag != attacker.tag]
        self._clash = any(self._clock - t < 0.5 for t in others)
        self._ttl = 1.4

    def update(self, dt: float) -> None:
        self._clock += dt
        self._ttl = max(0.0, self._ttl - dt)

    def draw(self, surface: pygame.Surface) -> None:
        if self._ttl <= 0:
            return
        cx, y = S.ARENA.centerx, S.GROUND_Y - 78
        big = get_font(26, bold=False, display=False).render("CLASH!" if self._clash else "COMBO!", True, S.DARK)
        r = big.get_rect(center=(cx, y)).inflate(24, 10)
        pygame.draw.rect(surface, S.WHITE, r)
        surface.blit(big, big.get_rect(center=r.center))
        sub = get_font(11).render(f"{self._hits} HITS • {int(self._dmg * 10):,} DMG", True, S.DARK)
        sr = sub.get_rect(center=(cx, r.bottom + 12)).inflate(16, 6)
        pygame.draw.rect(surface, S.GOLD, sr)
        surface.blit(sub, sub.get_rect(center=sr.center))


# --------------------------------------------------------- character select
class FighterCard:
    """การ์ดผู้เล่นในหน้าเลือกตัวละคร: พอร์ตเทรต ชื่อ สกิล 3 ท่า และแถบสเตตัส

    ถ้าไม่มีรูปพอร์ตเทรต จะใช้ emptyImage.png หรือวาด placeholder ด้วยโค้ด (ดู assets.ImageLoader)
    """

    def __init__(self, rect: pygame.Rect, color: tuple[int, int, int], label: str, mirrored: bool) -> None:
        self.rect = rect
        self.color = color
        self.label = label
        self.mirrored = mirrored

    def draw(self, surface: pygame.Surface, name: str, title: str, preview: Optional["Fighter"], ready: bool) -> None:
        r, col = self.rect, self.color
        pygame.draw.rect(surface, S.PANEL, r)
        pygame.draw.rect(surface, col, r, 2)
        left = not self.mirrored
        draw_text(surface, f"PLAYER {self.label}", 12, col, (r.x + 20, r.y + 20) if left else (r.right - 20, r.y + 20),
                  "topleft" if left else "topright")
        badge = pygame.Rect(0, 0, 84, 24)
        badge.topright = (r.right - 14, r.y + 14) if left else (r.x + 98, r.y + 14)
        pygame.draw.rect(surface, col if ready else S.PANEL_LIGHT, badge)
        draw_text(surface, f"P{self.label} READY" if ready else "CHOOSING", 11, S.DARK if ready else S.GREY,
                  badge.center, "center")

        port = pygame.Rect(r.x + 20, r.y + 52, r.w - 40, 150)
        surface.blit(ImageLoader.load(f"assets/portraits/{name.lower()}.png", port.size, f"PORTRAIT {name}", col), port)
        pygame.draw.rect(surface, col, port, 1)

        ax, anchor = (r.x + 20, "topleft") if left else (r.right - 20, "topright")
        draw_text(surface, name, 44, S.WHITE, (ax, r.y + 212), anchor, display=True)
        draw_text(surface, title, 12, S.GREY, (ax, r.y + 262), anchor)
        if preview is None:
            draw_text(surface, "LOCKED", 22, S.GREY, (r.centerx, r.y + 400), "center")
            return
        draw_text(surface, "COMBAT SKILLS", 12, col, (ax, r.y + 288), anchor)
        for i, sk in enumerate(preview.skills):
            sr = pygame.Rect(r.x + 20, r.y + 312 + i * 72, r.w - 40, 66)
            pygame.draw.rect(surface, S.PANEL_LIGHT, sr)
            ic = (sr.x + 32, sr.centery) if left else (sr.right - 32, sr.centery)
            pygame.draw.circle(surface, col, ic, 20, 2)
            draw_icon(surface, sk.ICON, ic, col)
            kb = pygame.Rect(0, 0, 58, 16)
            if left:
                kb.topright = (sr.right - 8, sr.y + 6)
                name_x, desc_x, desc_w = sr.x + 64, sr.x + 64, sr.w - 74
            else:
                kb.topleft = (sr.x + 8, sr.y + 6)
                name_x, desc_x, desc_w = sr.x + 74, sr.x + 12, sr.w - 76
            pygame.draw.rect(surface, col, kb)
            draw_text(surface, f"[ {sk.key_label} ]", 9, S.DARK, kb.center, "center")
            draw_text(surface, sk.NAME, 11, S.WHITE, (name_x, sr.y + 6))
            for j, line in enumerate(wrap_text(sk.DESCRIPTION, 10, desc_w)[:3]):
                draw_text(surface, line, 10, S.GREY, (desc_x, sr.y + 24 + j * 13))
        stats = preview.stats_percent
        for i, key in enumerate(("PWR", "DEF", "SPD", "SPC")):
            bx = r.x + 20 + (i % 2) * ((r.w - 40) // 2 + 6)
            by = r.y + 536 + (i // 2) * 28
            bw = (r.w - 40) // 2 - 12
            draw_text(surface, key, 10, S.WHITE, (bx, by))
            draw_text(surface, f"{stats[key]}%", 10, S.WHITE, (bx + bw, by), "topright")
            pygame.draw.rect(surface, S.DARK, (bx, by + 14, bw, 5))
            pygame.draw.rect(surface, col, (bx, by + 14, int(bw * stats[key] / 100), 5))


class RosterGrid:
    """ตารางรายชื่อนักสู้ 8 ช่อง พร้อมตัวชี้ 1P/2P"""

    def __init__(self, rect: pygame.Rect, names: list[str], playable: list[bool]) -> None:
        self.rect = rect
        self.names = names
        self.playable = playable

    def cell(self, i: int) -> pygame.Rect:
        w = (self.rect.w - 40 - 12) // 2
        return pygame.Rect(self.rect.x + 20 + (i % 2) * (w + 12), self.rect.y + 60 + (i // 2) * 132, w, 120)

    def draw(self, surface: pygame.Surface, cursors: tuple[int, int], ready: tuple[bool, bool]) -> None:
        pygame.draw.rect(surface, S.PANEL, self.rect)
        pygame.draw.rect(surface, S.PANEL_LIGHT, self.rect, 1)
        draw_text(surface, f"ROSTER - {len(self.names)} AVAILABLE", 13, S.WHITE, (self.rect.centerx, self.rect.y + 30), "center")
        for i, name in enumerate(self.names):
            c = self.cell(i)
            pygame.draw.rect(surface, S.PANEL_LIGHT, c)
            pygame.draw.rect(surface, (60, 60, 70), c, 1)
            col = S.WHITE if self.playable[i] else S.GREY
            pygame.draw.circle(surface, col, (c.centerx, c.centery - 18), 8, 2)
            pygame.draw.arc(surface, col, (c.centerx - 14, c.centery - 8, 28, 24), 0, 3.1416, 2)
            draw_text(surface, name, 12, col, (c.centerx, c.centery + 24), "center")
            draw_text(surface, "[ PORTRAIT ]" if self.playable[i] else "[ LOCKED ]", 9, S.GREY, (c.centerx, c.centery + 40), "center")
        for p, (col, tag) in enumerate(((S.P1_COLOR, "1P"), (S.P2_COLOR, "2P"))):
            c = self.cell(cursors[p])
            inset = c.inflate(-4 * p, -4 * p)
            pygame.draw.rect(surface, col, inset, 2 if not ready[p] else 4)
            b = pygame.Rect(0, 0, 26, 16)
            b.topleft = (c.x, c.y) if p == 0 else (c.right - 26, c.y)
            pygame.draw.rect(surface, col, b)
            draw_text(surface, tag, 10, S.DARK, b.center, "center")
