# STREET CLASH — 2-player Pygame fighter

    pip install -r requirements.txt
    python main.py

Optional: put `emptyImage.png` next to main.py (or in assets/) and/or portraits in
`assets/portraits/kai.png`, `nyx.png`. Without them, placeholders are drawn procedurally.

| | Player 1 (Kai) | Player 2 (Nyx) |
|---|---|---|
| Move / jump / guard | A D / W / S | Arrows (← → / ↑ / ↓) |
| Attack | F | Right Shift (or Numpad 0) |
| Skills | Q  E  C | Num 1 2 3 (or top-row 1 2 3) |

Select screen: move cursor with move keys, confirm with Attack. Best of 3 rounds.
