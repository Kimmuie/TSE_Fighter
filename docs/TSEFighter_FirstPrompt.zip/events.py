"""events.py — ระบบเหตุการณ์แบบ Observer (หลักการ OOP ข้อ 8)

มี 2 คลาส:
  * EventDispatcher : ตัวกลางส่งเหตุการณ์ (on_hit, on_skill_cast, on_ko)
  * HitInfo         : ข้อมูลการโจมตีหนึ่งครั้ง ส่งต่อให้ผู้ถูกโจมตีประมวลผล
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable

import pygame

if TYPE_CHECKING:
    from entities import Fighter

Listener = Callable[..., None]


class EventDispatcher:
    """ตัวส่งเหตุการณ์ (Subject) ตามรูปแบบ Observer

    ผู้สนใจเหตุการณ์ (เช่น HUD, ตัวนับคอมโบ, ฉากต่อสู้) เรียก subscribe() ไว้
    เมื่อนักสู้โดนตี/ใช้สกิล/KO จะเรียก emit() แล้ว listener ทุกตัวถูกเรียกพร้อมกัน
    โดยที่ Fighter ไม่ต้องรู้จัก UI หรือ Scene เลย (Loose coupling)
    """

    def __init__(self) -> None:
        self._listeners: dict[str, list[Listener]] = defaultdict(list)

    def subscribe(self, event_name: str, listener: Listener) -> None:
        """ลงทะเบียน listener ให้กับเหตุการณ์ที่ระบุ"""
        self._listeners[event_name].append(listener)

    def unsubscribe(self, event_name: str, listener: Listener) -> None:
        """ยกเลิกการลงทะเบียน"""
        if listener in self._listeners[event_name]:
            self._listeners[event_name].remove(listener)

    def emit(self, event_name: str, **payload: Any) -> None:
        """ส่งเหตุการณ์พร้อมข้อมูลไปยัง listener ทุกตัว"""
        for listener in list(self._listeners[event_name]):
            listener(**payload)


@dataclass
class HitInfo:
    """ข้อมูลการโจมตีหนึ่งครั้ง (Value Object)

    attacker   : ผู้โจมตี
    damage     : ดาเมจดิบ (ก่อนคำนวณค่าป้องกัน)
    knockback  : แรงกระเด็น (x สัมพันธ์กับทิศ direction)
    direction  : ทิศของการโจมตี (+1 ขวา / -1 ซ้าย)
    unblockable: True = ป้องกันไม่ได้
    stun       : เวลาที่เป้าหมายค้าง (วินาที)
    tags       : แท็กพิเศษ เช่น {"wall_bounce"}, {"counter"}
    """

    attacker: "Fighter"
    damage: float
    knockback: pygame.Vector2 = field(default_factory=pygame.Vector2)
    direction: int = 1
    unblockable: bool = False
    stun: float = 0.3
    tags: frozenset[str] = frozenset()
