"""assets.py — โหลดฟอนต์และรูปภาพ พร้อมระบบ fallback

ลำดับการหารูป:  ไฟล์ที่ร้องขอ  ->  emptyImage.png  ->  วาดสี่เหลี่ยมพร้อมข้อความด้วยโค้ด
ดังนั้นเกมรันได้เสมอแม้ไม่มีไฟล์รูปใดๆ
"""
from __future__ import annotations

import os
from typing import Optional

import pygame

import settings as S

_BASE = os.path.dirname(os.path.abspath(__file__))
_FALLBACK_NAME = "emptyImage.png"

_font_cache: dict[tuple[int, bool, bool], pygame.font.Font] = {}
_image_cache: dict[tuple, pygame.Surface] = {}


def get_font(size: int, bold: bool = True, display: bool = False) -> pygame.font.Font:
    """ฟอนต์ที่แคชแล้ว  display=True ใช้ฟอนต์หัวข้อตัวหนาแคบ, ไม่งั้นใช้ monospace"""
    key = (size, bold, display)
    if key not in _font_cache:
        names = (
            "impact,oswald,bebasneue,arialblack,arial"
            if display
            else "couriernew,courier,menlo,consolas,dejavusansmono,monospace"
        )
        _font_cache[key] = pygame.font.SysFont(names, size, bold=bold)
    return _font_cache[key]


class ImageLoader:
    """ตัวโหลดรูปภาพพร้อม fallback (ใช้เป็น static utility)"""

    @staticmethod
    def _find_fallback() -> Optional[str]:
        for folder in (_BASE, os.path.join(_BASE, "assets")):
            path = os.path.join(folder, _FALLBACK_NAME)
            if os.path.isfile(path):
                return path
        return None

    @staticmethod
    def procedural(size: tuple[int, int], label: str, color: tuple[int, int, int]) -> pygame.Surface:
        """วาดรูปแทนที่ (placeholder) ด้วยโค้ด: กรอบ + ไอคอนคน + ข้อความ"""
        surf = pygame.Surface(size, pygame.SRCALPHA)
        surf.fill(S.PANEL)
        pygame.draw.rect(surf, color, surf.get_rect(), 2)
        cx, cy = size[0] // 2, size[1] // 2 - 8
        r = max(4, min(size) // 10)
        pygame.draw.circle(surf, color, (cx, cy - r), r, 2)
        pygame.draw.arc(surf, color, (cx - 2 * r, cy, 4 * r, 3 * r), 0, 3.1416, 2)
        if label:
            txt = get_font(max(9, min(size) // 9), bold=False).render(f"[ {label} ]", True, color)
            surf.blit(txt, txt.get_rect(center=(size[0] // 2, size[1] - max(10, size[1] // 8))))
        return surf

    @classmethod
    def load(
        cls, path: str, size: tuple[int, int], label: str = "", color: tuple[int, int, int] = S.WHITE
    ) -> pygame.Surface:
        key = (path, size, label, color)
        if key in _image_cache:
            return _image_cache[key]
        full = path if os.path.isabs(path) else os.path.join(_BASE, path)
        surf: Optional[pygame.Surface] = None
        for candidate in (full, cls._find_fallback()):
            if candidate and os.path.isfile(candidate):
                try:
                    surf = pygame.transform.smoothscale(pygame.image.load(candidate).convert_alpha(), size)
                    break
                except pygame.error:
                    surf = None
        if surf is None:
            surf = cls.procedural(size, label, color)
        _image_cache[key] = surf
        return surf
