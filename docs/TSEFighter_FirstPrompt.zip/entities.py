"""entities.py — วัตถุทั้งหมดที่อยู่ในสนาม

โครงสร้างการสืบทอด (Inheritance, หลักการ OOP ข้อ 4):

    pygame.sprite.Sprite + ABC
        └── GameObject            (ฟิสิกส์: ตำแหน่ง ความเร็ว แรงโน้มถ่วง กรอบ rect)
              ├── Particle        (เศษประกายเอฟเฟกต์)
              ├── FloatingText    (ข้อความลอย)
              ├── SmokeScreen     (ม่านควันของ Nyx)
              ├── Projectile      (กระสุน)
              │     └── KunaiProjectile
              └── Fighter  (+ BaseFighter ABC)
                    ├── Kai
                    └── Nyx
"""
from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Optional

import pygame

import settings as S
from assets import get_font
from components import Hitbox, InputController, State, StateMachine
from events import EventDispatcher, HitInfo

if TYPE_CHECKING:
    from combat import BattleWorld
    from skills import BaseSkill


# =============================================================================
class GameObject(pygame.sprite.Sprite, ABC):
    """คลาสแม่ของทุกวัตถุในเกม (Abstract Base Class)

    ดูแลฟิสิกส์พื้นฐานที่ทุกวัตถุใช้ร่วมกัน: ตำแหน่ง (pos = กึ่งกลางด้านล่าง),
    ความเร็ว (vel), แรงโน้มถ่วง และกรอบสี่เหลี่ยม (rect)
    คลาสลูกต้อง override draw() ซึ่งเป็น abstract; ส่วน update() override ได้
    แล้วเรียก super().update(dt) ต่อ (Method Overriding)
    """

    def __init__(self, x: float, y: float, width: int, height: int, gravity: float = 0.0) -> None:
        super().__init__()
        self.pos = pygame.Vector2(x, y)          # midbottom
        self.vel = pygame.Vector2(0, 0)
        self.gravity = gravity
        self.on_ground = False
        self.rect = pygame.Rect(0, 0, width, height)
        self._sync_rect()

    def _sync_rect(self) -> None:
        self.rect.midbottom = (round(self.pos.x), round(self.pos.y))

    def set_x(self, x: float) -> None:
        """วาร์ป/ตั้งตำแหน่งแกน X พร้อมซิงก์ rect"""
        self.pos.x = x
        self._sync_rect()

    def update(self, dt: float, *args: object) -> None:  # noqa: D401
        """เดินฟิสิกส์ 1 เฟรม (dt หน่วยวินาที)"""
        if self.gravity:
            self.vel.y += self.gravity * dt
        self.pos += self.vel * dt
        if self.gravity and self.pos.y >= S.GROUND_Y:
            self.pos.y = S.GROUND_Y
            self.vel.y = 0.0
            self.on_ground = True
        elif self.gravity:
            self.on_ground = False
        self._sync_rect()

    @abstractmethod
    def draw(self, surface: pygame.Surface) -> None:
        """วาดตัวเองลงบน surface (คลาสลูกต้อง implement)"""


# =============================================================================
class Particle(GameObject):
    """เศษประกายเล็กๆ (เอฟเฟกต์โดนตี/สกิล) — หดตัวและหายไปตามอายุ"""

    def __init__(self, x: float, y: float, vx: float, vy: float,
                 color: tuple[int, int, int], life: float = 0.5, size: int = 6) -> None:
        super().__init__(x, y, size, size, gravity=900.0)
        self.vel.update(vx, vy)
        self._color = color
        self._life = self._max_life = life
        self._size = size

    def update(self, dt: float, *args: object) -> None:
        super().update(dt)
        self._life -= dt
        if self._life <= 0:
            self.kill()

    def draw(self, surface: pygame.Surface) -> None:
        k = max(0.0, self._life / self._max_life)
        s = max(1, int(self._size * k) + 1)
        pygame.draw.rect(surface, self._color, (self.rect.centerx - s // 2, self.rect.centery - s // 2, s, s))


class FloatingText(GameObject):
    """ข้อความลอยขึ้นแล้วจางหาย (ชื่อสกิล, WALL BOUNCE! ฯลฯ)"""

    def __init__(self, text: str, x: float, y: float, color: tuple[int, int, int], life: float = 0.9) -> None:
        super().__init__(x, y, 1, 1)
        self.vel.update(0, -55)
        self._img = get_font(16).render(text, True, color)
        self._life = self._max_life = life

    def update(self, dt: float, *args: object) -> None:
        super().update(dt)
        self._life -= dt
        if self._life <= 0:
            self.kill()

    def draw(self, surface: pygame.Surface) -> None:
        img = self._img.copy()
        img.set_alpha(int(255 * max(0.0, self._life / self._max_life)))
        surface.blit(img, img.get_rect(center=self.rect.midbottom))


class SmokeScreen(GameObject):
    """ม่านควันของ Shadow Veil — ติดตามเจ้าของและหายเมื่อสถานะ "veiled" หมด"""

    def __init__(self, owner: "Fighter", radius: int = 150) -> None:
        super().__init__(owner.pos.x, owner.pos.y, radius * 2, radius, gravity=0.0)
        self._owner = owner
        self._radius = radius
        self._puffs = [(random.uniform(-0.7, 0.7), random.uniform(0.0, 1.0), random.uniform(0.25, 0.5),
                        random.uniform(0.6, 1.6), random.uniform(0, 6.28)) for _ in range(14)]
        self._t = 0.0

    def update(self, dt: float, *args: object) -> None:
        self._t += dt
        self.pos.update(self._owner.pos.x, S.GROUND_Y)
        self._sync_rect()
        if not self._owner.has_status("veiled"):
            self.kill()

    def draw(self, surface: pygame.Surface) -> None:
        r = self._radius
        layer = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        for ox, oy, size, speed, phase in self._puffs:
            cx = r + ox * r + math.sin(self._t * speed + phase) * 10
            cy = r * 2 - 40 - oy * 150 + math.cos(self._t * speed + phase) * 6
            pygame.draw.circle(layer, (60, 55, 75, 105), (int(cx), int(cy)), int(r * size))
        surface.blit(layer, (self.rect.centerx - r, S.GROUND_Y - r * 2))


# =============================================================================
class Projectile(GameObject):
    """กระสุนทั่วไป: บินเป็นเส้นตรง ชนแล้วเรียก on_hit() (Template Method)"""

    def __init__(self, owner: "Fighter", x: float, y: float, vx: float, vy: float,
                 damage: float, lifespan: float = 1.6, size: tuple[int, int] = (30, 8)) -> None:
        super().__init__(x, y, size[0], size[1], gravity=0.0)
        self.owner = owner
        self.vel.update(vx, vy)
        self.damage = damage
        self._life = lifespan

    def update(self, dt: float, *args: object) -> None:
        super().update(dt)
        self._life -= dt
        if self._life <= 0 or not S.ARENA.inflate(80, 200).colliderect(self.rect):
            self.kill()

    def build_hit(self) -> HitInfo:
        return HitInfo(attacker=self.owner, damage=self.damage,
                       knockback=pygame.Vector2(160, -90),
                       direction=1 if self.vel.x >= 0 else -1, stun=0.2)

    def on_hit(self, target: "Fighter") -> None:
        """เรียกหลังชนสำเร็จ — คลาสลูก override เพื่อเพิ่มผลพิเศษ"""

    def draw(self, surface: pygame.Surface) -> None:
        pygame.draw.rect(surface, self.owner.color, self.rect)


class KunaiProjectile(Projectile):
    """คุไนพลังงานของ Nyx — เมื่อโดนจะทำให้ "เลือดไหล" (bleed) ต่อเนื่อง

    Override: on_hit() เพิ่มผล bleed, draw() วาดเป็นรูปมีดแหลม
    """

    def __init__(self, *args: object, bleed_dps: float = 0.7, bleed_time: float = 4.0, **kw: object) -> None:
        super().__init__(*args, **kw)  # type: ignore[arg-type]
        self._bleed_dps = bleed_dps
        self._bleed_time = bleed_time

    def on_hit(self, target: "Fighter") -> None:
        if not target.is_blocking:
            target.apply_bleed(self._bleed_dps, self._bleed_time, self.owner)

    def draw(self, surface: pygame.Surface) -> None:
        d = 1 if self.vel.x >= 0 else -1
        tip = (self.rect.centerx + d * 16, self.rect.centery)
        tail = (self.rect.centerx - d * 14, self.rect.centery)
        pygame.draw.polygon(surface, self.owner.color,
                            [tip, (tail[0], tail[1] - 5), (tail[0] + d * 6, tail[1]), (tail[0], tail[1] + 5)])
        pygame.draw.line(surface, S.WHITE, tip, (self.rect.centerx, self.rect.centery), 2)


# =============================================================================
class BaseFighter(ABC):
    """สัญญา (Contract) ของนักสู้ทุกคน — Abstract Base Class (หลักการ OOP ข้อ 7)

    นักสู้ทุกชนิดต้อง implement 3 ฮุคการต่อสู้นี้ ไม่เช่นนั้นสร้างอ็อบเจกต์ไม่ได้
    """

    @abstractmethod
    def create_skills(self) -> list["BaseSkill"]:
        """สร้างสกิล 3 ท่าของนักสู้"""

    @abstractmethod
    def on_damage_taken(self, hit: HitInfo, damage: float) -> None:
        """ฮุก: ถูกโจมตีสำเร็จ (หลังหัก HP แล้ว)"""

    @abstractmethod
    def on_hit_landed(self, hit: HitInfo, target: "Fighter") -> None:
        """ฮุก: โจมตีโดนเป้าหมาย"""


class Fighter(GameObject, BaseFighter):
    """นักสู้ — สืบทอดฟิสิกส์จาก GameObject และสัญญาจาก BaseFighter

    * Encapsulation: _hp, _energy, _stamina ถูกป้องกันด้วย @property + setter ที่ตรวจช่วงค่า
    * Composition  : ประกอบด้วย StateMachine, Hitbox, InputController และรายการ Skill
    * Template Method: take_hit() เรียกฮุกที่คลาสลูก override ได้
      (modify_incoming_damage, outgoing_damage_multiplier, attack_speed, move_speed_multiplier)
    * Observer     : ส่งเหตุการณ์ on_hit / on_ko ผ่าน EventDispatcher
    """

    NAME = "FIGHTER"
    TITLE = ""
    BASE_STATS: dict[str, int] = {"PWR": 50, "DEF": 50, "SPD": 50, "SPC": 50}
    SIZE = (70, 170)

    def __init__(self, color: tuple[int, int, int], controller: InputController,
                 dispatcher: EventDispatcher, tag: str = "1P", x: float = 300.0, facing: int = 1) -> None:
        super().__init__(x, S.GROUND_Y, self.SIZE[0], self.SIZE[1], gravity=S.GRAVITY)
        self.color = color
        self.tag = tag
        self.controller = controller
        self.dispatcher = dispatcher
        self.facing = 1 if facing >= 0 else -1
        self.input_enabled = True
        self.opponent: Optional["Fighter"] = None
        self.world: Optional["BattleWorld"] = None

        self._stats = {k: self._validate_percent(v) for k, v in self.BASE_STATS.items()}
        self._hp = S.MAX_HP
        self._energy = 50.0
        self._stamina = S.MAX_STAMINA
        self._status: dict[str, float] = {}
        self._bleeds: list[list[object]] = []
        self._blocking = False
        self._bounce_window = 0.0
        self._pose = "idle"
        self._pose_time = 0.0
        self._pose_len = 0.0

        self.state_machine = StateMachine()
        self.hitbox = Hitbox()
        self.skills: list["BaseSkill"] = self.create_skills()
        for i, skill in enumerate(self.skills, start=1):
            skill.bind(f"skill{i}", controller.label(f"skill{i}"))

    # ----------------------------------------------------- validated properties
    @staticmethod
    def _validate_percent(value: float) -> float:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError("stat must be a number")
        if not 0 <= value <= 100:
            raise ValueError("stat must be within 0..100")
        return float(value)

    @staticmethod
    def _clamp_resource(value: float, upper: float, name: str) -> float:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"{name} must be a number")
        return max(0.0, min(upper, float(value)))

    @property
    def hp(self) -> float:
        return self._hp

    @hp.setter
    def hp(self, value: float) -> None:
        self._hp = self._clamp_resource(value, S.MAX_HP, "hp")

    @property
    def energy(self) -> float:
        return self._energy

    @energy.setter
    def energy(self, value: float) -> None:
        self._energy = self._clamp_resource(value, S.MAX_ENERGY, "energy")

    @property
    def stamina(self) -> float:
        return self._stamina

    @stamina.setter
    def stamina(self, value: float) -> None:
        self._stamina = self._clamp_resource(value, S.MAX_STAMINA, "stamina")

    @property
    def power(self) -> float:
        return self._stats["PWR"] / 100.0

    @property
    def defense(self) -> float:
        return self._stats["DEF"] / 100.0

    @property
    def speed(self) -> float:
        return self._stats["SPD"] / 100.0

    @property
    def special(self) -> float:
        return self._stats["SPC"] / 100.0

    @property
    def stats_percent(self) -> dict[str, int]:
        return {k: int(v) for k, v in self._stats.items()}

    @property
    def is_ko(self) -> bool:
        return self.state_machine.state == State.KO

    @property
    def is_blocking(self) -> bool:
        return self._blocking

    # ------------------------------------------------------- overridable hooks
    def modify_incoming_damage(self, damage: float, hit: HitInfo, blocked: bool) -> float:
        """ฮุก: ปรับดาเมจที่ได้รับ (คลาสลูก override ได้)"""
        return damage

    def outgoing_damage_multiplier(self) -> float:
        """ฮุก: ตัวคูณดาเมจที่ปล่อยออก (คลาสลูก override ได้)"""
        return 1.0

    @property
    def attack_speed(self) -> float:
        """ฮุก: ความเร็วการโจมตี (1.0 = ปกติ)"""
        return 1.0

    @property
    def move_speed_multiplier(self) -> float:
        """ฮุก: ตัวคูณความเร็วการเดิน"""
        return 1.0

    # ------------------------------------------------------------ status/bleed
    def add_status(self, name: str, duration: float) -> None:
        self._status[name] = max(self._status.get(name, 0.0), duration)

    def has_status(self, name: str) -> bool:
        return self._status.get(name, 0.0) > 0.0

    def apply_bleed(self, dps: float, duration: float, source: "Fighter") -> None:
        """เพิ่มเลือดไหล (ดาเมจต่อเนื่อง) — ซ้อนกันได้"""
        self._bleeds.append([duration, dps, source])

    def play_pose(self, pose: str, length: float) -> None:
        self._pose, self._pose_time, self._pose_len = pose, 0.0, length

    def burst(self, count: int, color: Optional[tuple[int, int, int]] = None, speed: float = 260.0) -> None:
        if self.world is not None:
            self.world.spawn_particles(self.rect.centerx, self.rect.centery, color or self.color, count, speed)

    # --------------------------------------------------------------- lifecycle
    def reset(self, x: float, facing: int) -> None:
        """รีเซ็ตเพื่อเริ่มยกใหม่"""
        self.hp = S.MAX_HP
        self.energy = 50.0
        self.stamina = S.MAX_STAMINA
        self._status.clear()
        self._bleeds.clear()
        self._blocking = False
        self._bounce_window = 0.0
        self.pos.update(x, S.GROUND_Y)
        self.vel.update(0, 0)
        self.facing = facing
        self.hitbox.clear()
        self.state_machine.change(State.IDLE)
        self.play_pose("idle", 0.0)
        self.input_enabled = True
        for skill in self.skills:
            skill.reset()
        self._sync_rect()

    # ------------------------------------------------------------------- input
    def handle_event(self, event: pygame.event.Event) -> None:
        """รับ KEYDOWN แล้วแปลงเป็นคำสั่ง (กดครั้งเดียว: กระโดด/โจมตี/สกิล)"""
        if not self.input_enabled or self.is_ko:
            return
        action = self.controller.action_for_event(event)
        if action is not None:
            self.perform(action)

    def perform(self, action: str) -> None:
        if not self.state_machine.can_act:
            return
        if action == "jump" and self.on_ground:
            self.vel.y = -950.0
            self.on_ground = False
        elif action == "attack":
            self.basic_attack()
        elif action.startswith("skill"):
            idx = int(action[5:]) - 1
            if 0 <= idx < len(self.skills):
                self.skills[idx].try_cast(self, self.opponent)

    def basic_attack(self) -> None:
        if self.stamina < 8:
            return
        self.stamina -= 8
        spd = self.attack_speed
        self.state_machine.change(State.ATTACK, lock=0.32 / spd)
        self.hitbox.arm(damage=4 + 6 * self.power, width=84, height=54, offset_x=58, offset_y=112,
                        windup=0.07 / spd, active=0.12, knockback=(260, -120), stun=0.28)
        self.play_pose("punch", 0.25 / spd)

    def _handle_held_input(self, dt: float) -> None:
        self._blocking = False
        sm = self.state_machine
        if not sm.can_act:
            return
        if not self.input_enabled:
            if self.on_ground:
                self.vel.x = 0
                sm.locomote(State.IDLE)
            return
        pressed = pygame.key.get_pressed()
        ctrl = self.controller
        axis = int(ctrl.is_held("right", pressed)) - int(ctrl.is_held("left", pressed))
        if ctrl.is_held("block", pressed) and self.on_ground and self.stamina > 1:
            self._blocking = True
            axis = 0
            self.stamina -= S.BLOCK_DRAIN * dt
        speed = (200 + 180 * self.speed) * self.move_speed_multiplier
        if self.on_ground:
            self.vel.x = axis * speed
            sm.locomote(State.WALK if axis else State.IDLE)
        else:
            if axis:
                self.vel.x = axis * speed * 0.85
            sm.locomote(State.JUMP)

    # ------------------------------------------------------------------ update
    def update(self, dt: float, *args: object) -> None:
        self.state_machine.update(dt)
        self._pose_time += dt
        if self._pose_time > self._pose_len:
            self._pose = "idle"
        for name in list(self._status):
            self._status[name] -= dt
            if self._status[name] <= 0:
                del self._status[name]
        self._tick_bleeds(dt)

        if self.is_ko:
            self.vel.x *= 0.02 ** dt
            super().update(dt)
            self._handle_walls()
            return

        for skill in self.skills:
            skill.update(dt)
        self.energy += S.ENERGY_REGEN * dt
        self.stamina += S.STAMINA_REGEN * dt
        self._bounce_window = max(0.0, self._bounce_window - dt)
        self._handle_held_input(dt)
        self.hitbox.update(dt)
        if not self.state_machine.can_act and self.on_ground:
            self.vel.x *= 0.03 ** dt
        super().update(dt)
        self._handle_walls()
        if self.state_machine.can_act and self.opponent is not None:
            self.facing = 1 if self.opponent.pos.x >= self.pos.x else -1

    def _tick_bleeds(self, dt: float) -> None:
        if not self._bleeds or self.is_ko:
            return
        total, killer = 0.0, None
        for b in self._bleeds:
            b[0] = float(b[0]) - dt  # type: ignore[assignment]
            total += float(b[1])  # type: ignore[arg-type]
            killer = b[2]
        self._bleeds = [b for b in self._bleeds if float(b[0]) > 0]  # type: ignore[arg-type]
        self.hp -= total * dt
        if random.random() < dt * 9:
            self.burst(1, (170, 10, 30), 90)
        if self.hp <= 0 and killer is not None:
            self._die(killer)  # type: ignore[arg-type]

    def _handle_walls(self) -> None:
        left, right = S.ARENA.left + 8, S.ARENA.right - 8
        touching = self.rect.left <= left or self.rect.right >= right
        if touching and self._bounce_window > 0 and abs(self.vel.x) > 60 and not self.is_ko:
            self.vel.x = -self.vel.x * 0.8
            self.vel.y = -380.0
            self._bounce_window = 0.0
            self.hp -= 4.0
            self.burst(14, S.WHITE, 300)
            if self.world is not None:
                self.world.spawn_effect(FloatingText("WALL BOUNCE!", self.pos.x, self.pos.y - 190, S.GOLD))
            if self.hp <= 0 and self.opponent is not None:
                self._die(self.opponent)
        if self.rect.left < left:
            self.pos.x += left - self.rect.left
        elif self.rect.right > right:
            self.pos.x -= self.rect.right - right
        self._sync_rect()

    # ------------------------------------------------------------------ combat
    def take_hit(self, hit: HitInfo) -> bool:
        """รับการโจมตี — คืน True ถ้าโดน (False ถ้าอยู่ในช่วงอมตะ/KO)"""
        if self.is_ko or self.has_status("invulnerable"):
            return False
        blocked = self._blocking and not hit.unblockable
        damage = hit.damage * (1.35 - 0.6 * self.defense)
        if blocked:
            damage *= 0.25
        damage = max(0.0, self.modify_incoming_damage(damage, hit, blocked))
        self.hp -= damage
        self.dispatcher.emit("on_hit", attacker=hit.attacker, target=self, damage=damage,
                             blocked=blocked, hit=hit)
        if blocked:
            self.vel.x = hit.direction * 120.0
        else:
            self.vel.update(hit.knockback.x * hit.direction, hit.knockback.y)
            if hit.knockback.y < 0:
                self.on_ground = False
            self.state_machine.change(State.HIT, lock=hit.stun)
            self.hitbox.clear()
            self.play_pose("hit", hit.stun)
            if "wall_bounce" in hit.tags:
                self._bounce_window = 0.9
        if self.hp <= 0:
            self._die(hit.attacker)
        else:
            self.on_damage_taken(hit, damage)
        return True

    def _die(self, killer: "Fighter") -> None:
        if self.is_ko:
            return
        self.hp = 0.0
        self._blocking = False
        self.hitbox.clear()
        self.state_machine.change(State.KO, lock=999.0)
        self.vel.update(-self.facing * 250.0, -500.0)
        self.on_ground = False
        self.dispatcher.emit("on_ko", loser=self, winner=killer)

    # -------------------------------------------------------------------- draw
    def draw(self, surface: pygame.Surface) -> None:
        shadow = pygame.Rect(0, 0, 90, 14)
        shadow.center = (self.rect.centerx, S.GROUND_Y + 2)
        pygame.draw.ellipse(surface, (150, 100, 0), shadow)
        alpha = 255
        if self.has_status("veiled"):
            alpha = 80
        elif self.has_status("invulnerable"):
            alpha = 110
        if alpha < 255:
            tmp = pygame.Surface((300, 300), pygame.SRCALPHA)
            self._draw_stick(tmp, 150, 280)
            tmp.set_alpha(alpha)
            surface.blit(tmp, (self.rect.centerx - 150, self.rect.bottom - 280))
        else:
            self._draw_stick(surface, self.rect.centerx, self.rect.bottom)
            self._draw_tag(surface)

    def _draw_tag(self, surface: pygame.Surface) -> None:
        img = get_font(12).render(f"{self.tag} • {self.NAME}", True, S.DARK)
        r = img.get_rect(center=(self.rect.centerx, self.rect.bottom - 208)).inflate(14, 8)
        pygame.draw.rect(surface, self.color, r)
        surface.blit(img, img.get_rect(center=r.center))

    @staticmethod
    def _limb(surf: pygame.Surface, col: tuple[int, int, int], a, b, c) -> None:
        pygame.draw.line(surf, col, a, b, 8)
        pygame.draw.line(surf, col, b, c, 8)
        pygame.draw.circle(surf, col, b, 4)
        pygame.draw.circle(surf, col, c, 4)

    def _draw_stick(self, surf: pygame.Surface, cx: int, gy: int) -> None:
        f = self.facing
        state = self.state_machine.state
        flash = state == State.HIT and self.state_machine.elapsed < 0.07
        col = S.WHITE if flash else self.color
        if state == State.KO:
            self._draw_ko(surf, cx, gy, col)
            return
        t = pygame.time.get_ticks() / 1000.0
        lean = -f * 10 if state == State.HIT else 0
        V = pygame.Vector2
        hip, sh, head = V(cx, gy - 82), V(cx + lean, gy - 134), V(cx + lean * 1.4, gy - 156)

        for i in (0, 1):
            sign = 1 if i == 0 else -1
            if not self.on_ground:
                foot = V(hip.x + sign * 16, hip.y + 50 - (8 if i == 0 else 0))
            elif state == State.WALK:
                ph = t * 11 + (0 if i == 0 else math.pi)
                foot = V(hip.x + math.sin(ph) * 34, gy - max(0.0, math.cos(ph)) * 14)
            else:
                foot = V(hip.x + sign * 18, gy)
            knee = (hip + foot) / 2 + V(f * 12, -2)
            self._limb(surf, col, hip, knee, foot)
        pygame.draw.line(surf, col, hip, sh, 8)

        pose = "block" if self._blocking else self._pose
        p = min(1.0, self._pose_time / 0.12)
        swing = math.sin(t * 11) * 10 if state == State.WALK else 0
        b_el, b_hand = sh + V(-f * 6, 18), sh + V(-f * 22, 30 + swing)
        f_el, f_hand = sh + V(f * 16, 18), sh + V(f * 34, 4)
        if pose == "punch":
            f_hand = sh + V(f * (38 + 52 * p), -6)
            f_el = (sh + f_hand) / 2 + V(0, 10)
        elif pose == "uppercut":
            f_hand = sh + V(f * (32 + 14 * p), 10 - 84 * p)
            f_el = sh + V(f * 22, 14 - 30 * p)
        elif pose == "throw":
            f_hand = sh + V(f * (36 + 54 * p), -16 * p)
            f_el = (sh + f_hand) / 2 + V(0, 8)
        elif pose == "cast":
            f_hand = sh + V(f * 30, -50 * p)
            b_hand = sh + V(f * 8, -46 * p)
        elif pose == "rush":
            k = abs(math.sin(t * 30))
            f_hand = sh + V(f * (44 + 46 * k), -8)
            b_hand = sh + V(f * (44 + 46 * (1 - k)), 10)
            f_el, b_el = (sh + f_hand) / 2, (sh + b_hand) / 2
        elif pose == "block":
            f_hand, f_el = sh + V(f * 26, -22), sh + V(f * 18, 14)
            b_hand, b_el = sh + V(f * 18, -10), sh + V(f * 10, 16)
        self._limb(surf, col, sh, b_el, b_hand)
        self._limb(surf, col, sh, f_el, f_hand)

        pygame.draw.circle(surf, col, head, 20)
        pygame.draw.circle(surf, S.DARK, head + V(f * 4, -1), 11)
        pygame.draw.circle(surf, S.WHITE, head + V(f * 7, -5), 3)
        if self._blocking:
            x = cx + f * 46
            pygame.draw.line(surf, S.WHITE, (x, gy - 150), (x, gy - 50), 4)

    @staticmethod
    def _draw_ko(surf: pygame.Surface, cx: int, gy: int, col: tuple[int, int, int]) -> None:
        pygame.draw.circle(surf, col, (cx - 62, gy - 20), 20)
        pygame.draw.circle(surf, S.DARK, (cx - 58, gy - 20), 8)
        pygame.draw.line(surf, col, (cx - 42, gy - 16), (cx + 34, gy - 12), 8)
        pygame.draw.line(surf, col, (cx + 34, gy - 12), (cx + 72, gy - 30), 8)
        pygame.draw.line(surf, col, (cx + 34, gy - 12), (cx + 74, gy - 6), 8)
        pygame.draw.line(surf, col, (cx - 30, gy - 16), (cx - 14, gy - 46), 8)


# =============================================================================
class Kai(Fighter):
    """KAI (The Urban Brawler) — นักสู้สายพลัง/ป้องกัน โมเมนตัมจลน์

    Override ฮุกหลายตัว (Method Overriding & Behavioral Specialization):
      * modify_incoming_damage : ขณะ Kinetic Charge ทำงานและป้องกันอยู่ จะ "ดูดซับ" ดาเมจเก็บเป็นพลัง
      * outgoing_damage_multiplier : ดาเมจเพิ่มตามพลังที่เก็บไว้
      * attack_speed / move_speed_multiplier : เร็วขึ้นขณะ Kinetic Charge
    """

    NAME = "KAI"
    TITLE = "THE URBAN BRAWLER"
    BASE_STATS = {"PWR": 90, "DEF": 70, "SPD": 85, "SPC": 95}

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)  # type: ignore[arg-type]
        self._kinetic_bank = 0.0

    def create_skills(self) -> list["BaseSkill"]:
        from skills import KineticCharge, OverdriveRush, PlasmaHook  # import ภายในเพื่อเลี่ยง circular import
        return [PlasmaHook(), KineticCharge(), OverdriveRush()]

    def modify_incoming_damage(self, damage: float, hit: HitInfo, blocked: bool) -> float:
        if blocked and self.has_status("kinetic"):
            self._kinetic_bank = min(30.0, self._kinetic_bank + damage * 2)
            self.energy += damage * 2
            self.burst(6, S.WHITE, 200)
            return 0.0
        return damage

    def outgoing_damage_multiplier(self) -> float:
        return 1.0 + self._kinetic_bank / 40.0

    @property
    def attack_speed(self) -> float:
        return 1.5 if self.has_status("kinetic") else 1.0

    @property
    def move_speed_multiplier(self) -> float:
        return 1.45 if self.has_status("kinetic") else 1.0

    def on_damage_taken(self, hit: HitInfo, damage: float) -> None:
        self.energy += damage * 0.5  # ยิ่งโดนตี ยิ่งได้โมเมนตัม

    def on_hit_landed(self, hit: HitInfo, target: Fighter) -> None:
        self.energy += 6
        self._kinetic_bank = 0.0

    def reset(self, x: float, facing: int) -> None:
        super().reset(x, facing)
        self._kinetic_bank = 0.0


class Nyx(Fighter):
    """NYX (Shadow Shinobi) — นักฆ่าสายความเร็ว หลบหลีก และดาเมจต่อเนื่อง

    Override ฮุก:
      * modify_incoming_damage : ขณะ Shadow Veil ลดดาเมจลงครึ่งหนึ่ง (hitbox ถูกซ่อน)
      * outgoing_damage_multiplier : ขณะ Veil โจมตีเป็น Critical x1.5
      * on_damage_taken : ขณะ Veil ถูกโจมตีแล้ว "สวนกลับ Critical" แน่นอน
    """

    NAME = "NYX"
    TITLE = "SHADOW SHINOBI"
    BASE_STATS = {"PWR": 75, "DEF": 60, "SPD": 98, "SPC": 90}

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)  # type: ignore[arg-type]
        self._counter_cd = 0.0

    def create_skills(self) -> list["BaseSkill"]:
        from skills import NaniteKunai, PhantomDash, ShadowVeil
        return [PhantomDash(), NaniteKunai(), ShadowVeil()]

    def update(self, dt: float, *args: object) -> None:
        self._counter_cd = max(0.0, self._counter_cd - dt)
        super().update(dt)

    def modify_incoming_damage(self, damage: float, hit: HitInfo, blocked: bool) -> float:
        return damage * 0.5 if self.has_status("veiled") else damage

    def outgoing_damage_multiplier(self) -> float:
        return 1.5 if self.has_status("veiled") else 1.0

    def on_damage_taken(self, hit: HitInfo, damage: float) -> None:
        if not self.has_status("veiled") or self._counter_cd > 0 or "counter" in hit.tags:
            return
        self._counter_cd = 0.6
        crit = (6 + 8 * self.special) * 2.0
        counter = HitInfo(attacker=self, damage=crit, knockback=pygame.Vector2(420, -320),
                          direction=1 if hit.attacker.pos.x >= self.pos.x else -1,
                          unblockable=True, stun=0.45, tags=frozenset({"counter", "crit"}))
        if self.world is not None:
            self.world.spawn_effect(FloatingText("CRITICAL COUNTER!", self.pos.x, self.pos.y - 190, S.WHITE))
        hit.attacker.take_hit(counter)

    def on_hit_landed(self, hit: HitInfo, target: Fighter) -> None:
        self.energy += 5
